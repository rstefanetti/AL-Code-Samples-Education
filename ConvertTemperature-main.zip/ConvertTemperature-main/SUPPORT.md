# Support

## How to file issues and get help  

This GitHub repo is auto-generated from https://github.com/microsoft/AL-Go
Issues, bug tracking and feature requests should be done there.

Please follow the documentation [here](https://github.com/microsoft/AL-Go/blob/main/Scenarios/Contribute.md) if you want to contribute to AL-Go for GitHub.

## Microsoft Support Policy  

Support for this **PROJECT or PRODUCT** is limited to the resources listed above.
