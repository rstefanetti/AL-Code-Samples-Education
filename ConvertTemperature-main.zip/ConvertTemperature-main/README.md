# AL-Go Template
## AppSource App Project
This template repository can be used for managing AppSource Apps for Business Central.

Please consult https://github.com/microsoft/AL-Go/#readme for scenarios on usage
